package com.example.thuchanh2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast; // [cite: 717]
import androidx.appcompat.app.AppCompatActivity;

public class Lab4TopicListActivity extends AppCompatActivity {

    private static final int[] ID_DRAWABLES = {R.drawable.ic_mess, R.drawable.ic_flight,
            R.drawable.ic_hospital, R.drawable.ic_hotel, R.drawable.ic_restaurant, R.drawable.ic_coctail,
            R.drawable.ic_store, R.drawable.ic_at_work, R.drawable.ic_time, R.drawable.ic_education,
            R.drawable.ic_movie}; // [cite: 433-435]

    private static final int[] ID_TEXTS = {R.string.txt_mess, R.string.txt_flight, R.string.txt_hospital,
            R.string.txt_hotel, R.string.txt_restaurant, R.string.txt_coctail,
            R.string.txt_store, R.string.txt_work, R.string.txt_time, R.string.txt_education, R.string.txt_movie}; // [cite: 436-438]

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab4_topiclist); // [cite: 442]
        initView(); // [cite: 443]
    }

    private void initView() {
        LinearLayout InMain = findViewById(R.id.In_main); // [cite: 445]
        InMain.removeAllViews(); // [cite: 446]

        for (int i = 0; i < ID_DRAWABLES.length; i++) { // [cite: 448]
            View v = LayoutInflater.from(this).inflate(R.layout.item_topic, null); // [cite: 449]
            ImageView ivTopic = v.findViewById(R.id.iv_topic); // [cite: 450]
            TextView tvTopic = v.findViewById(R.id.tv_topic); // [cite: 451]

            ivTopic.setImageResource(ID_DRAWABLES[i]);

            String topicName = getString(ID_TEXTS[i]); // Lấy tên chủ đề
            tvTopic.setText(topicName);

            LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1.0f
            ); // [cite: 453-456]
            v.setLayoutParams(param); // [cite: 457]

            // GIẢI BÀI TẬP 2 [cite: 717]
            final int index = i;
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String message = "Bạn đã chọn chủ đề: " + topicName;
                    // Bài tập yêu cầu hiển thị một số từ vựng
                    // Ví dụ:
                    if(topicName.equals("Essentials")) {
                        message += "\nTừ vựng: Hello, Goodbye, Thanks";
                    }
                    Toast.makeText(Lab4TopicListActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
            // Hết phần giải bài tập

            InMain.addView(v); // [cite: 461]
        }
    }
}