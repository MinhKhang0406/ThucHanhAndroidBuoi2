package com.example.thuchanh2;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.util.Random; // [cite: 719]

public class FragmentFaceEmoij extends Fragment implements View.OnClickListener {
    private static final int[] ids = {R.id.iv_face1, R.id.iv_face2, R.id.iv_face3, R.id.iv_face4,
            R.id.iv_face5, R.id.iv_face6, R.id.iv_face7, R.id.iv_face8, R.id.iv_face9};

    // GIẢI BÀI TẬP 3 [cite: 719]
    private static final int[] drawables = {
            R.drawable.ic_angry, R.drawable.ic_baffle, R.drawable.ic_beauty,
            R.drawable.ic_boss, R.drawable.ic_choler, R.drawable.ic_dribble,
            R.drawable.ic_look_down, R.drawable.ic_sure, R.drawable.ic_tire
    };
    private ImageView[] imageViews = new ImageView[ids.length];
    private Random random = new Random();
    // Hết phần khai báo

    private Context mContext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m001_frg_face_emoij, container, false);
        initViews(rootView);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        mContext = context;
        super.onAttach(context);
    }

    private void initViews(View v) {
        for (int i = 0; i < ids.length; i++) {
            imageViews[i] = v.findViewById(ids[i]); // Lưu trữ ImageView
            imageViews[i].setOnClickListener(this);
        }

        // GIẢI BÀI TẬP 3: Xử lý nút Random
        v.findViewById(R.id.btn_random).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                randomizeEmojis();
            }
        });
    }

    // GIẢI BÀI TẬP 3: Hàm random
    private void randomizeEmojis() {
        for (ImageView iv : imageViews) {
            int randomIndex = random.nextInt(drawables.length);
            int randomDrawableRes = drawables[randomIndex];
            iv.setImageResource(randomDrawableRes);
        }
        Toast.makeText(mContext, "Đã random icon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        // Code gốc từ PDF
        ImageView ivFace = (ImageView) v;
        showToast(ivFace.getDrawable()); // [cite: 678]
    }

    private void showToast(Drawable drawable) {
        // Code gốc từ PDF
        Toast toast = new Toast(mContext); // [cite: 681]
        ImageView ivEmoij = new ImageView(mContext); // [cite: 682]
        ivEmoij.setImageDrawable(drawable); // [cite: 683]
        toast.setView(ivEmoij); // [cite: 684]
        toast.show(); // [cite: 685]
    }
}