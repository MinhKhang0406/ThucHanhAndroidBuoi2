package com.example.thuchanh2;

import android.os.Bundle;
import android.os.Handler; // [cite: 881]
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment; // [cite: 885]

public class M000SplashFrg extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.m000_frg_splash, container, false); // [cite: 892]
        initViews(); // [cite: 890]
        return v;
    }

    private void initViews() {
        // Chuyển màn hình sau 2 giây
        new Handler().postDelayed(this::gotoM001Screen, 2000); // [cite: 895]
    }

    private void gotoM001Screen() {
        // [cite: 897]
        if (getActivity() instanceof Lab3SplashActivity) {
            ((Lab3SplashActivity) getActivity()).gotoM001Screen();
        }
    }
}