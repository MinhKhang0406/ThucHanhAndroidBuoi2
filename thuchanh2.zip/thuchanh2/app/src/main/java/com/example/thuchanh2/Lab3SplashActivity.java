package com.example.thuchanh2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

// Xin lưu ý: PDF Lab 3 chỉ cung cấp code cho màn hình Splash
// và không cung cấp code cho M001, M002, M003.
// Tôi sẽ đổi tên MainActivity thành Lab3SplashActivity để tránh trùng lặp.
public class Lab3SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab3); // [cite: 861]
        showFrg(new M000SplashFrg()); // [cite: 914]
    }

    private void showFrg(Fragment frg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null) // [cite: 867, 916]
                .commit(); // [cite: 917]
    }

    public void gotoM001Screen() {
        // PDF không cung cấp code cho M001Screen
        // gotoM001Screen();
    }

    // Các hàm khác từ PDF
    // public void gotoM002Screen (String topicName) {}
    // public void backToM001Screen() {}
    // public void gotoM003Screen (ArrayList<StoryEntity> listStory, StoryEntity story) {}
}