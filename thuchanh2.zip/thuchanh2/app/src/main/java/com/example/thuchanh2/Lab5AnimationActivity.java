package com.example.thuchanh2;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation; // Thêm
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random; // [cite: 1849]

public class Lab5AnimationActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivAnimal;

    // GIẢI BÀI TẬP 1 [cite: 1849]
    private int[] anims = {R.anim.alpha, R.anim.rotate, R.anim.scale, R.anim.translate};
    private Random random = new Random();
    // Hết

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab5_animation); // [cite: 1456]
        initViews(); // [cite: 1457]
    }

    private void initViews() {
        ivAnimal = findViewById(R.id.iv_animal); // [cite: 1460]
        findViewById(R.id.bt_alpha).setOnClickListener(this); // [cite: 1461]
        findViewById(R.id.bt_rotate).setOnClickListener(this); // [cite: 1462]
        findViewById(R.id.bt_scale).setOnClickListener(this); // [cite: 1463]
        findViewById(R.id.bt_trans).setOnClickListener(this); // [cite: 1464]
        findViewById(R.id.bt_random).setOnClickListener(this); // [cite: 1849]
    }

    @Override
    public void onClick(View v) {
        Animation animation = null;
        int id = v.getId();

        if (id == R.id.bt_alpha) {
            animation = AnimationUtils.loadAnimation(this, R.anim.alpha); // [cite: 1468]
        } else if (id == R.id.bt_rotate) {
            animation = AnimationUtils.loadAnimation(this, R.anim.rotate); // [cite: 1470]
        } else if (id == R.id.bt_scale) {
            animation = AnimationUtils.loadAnimation(this, R.anim.scale); // [cite: 1471]
        } else if (id == R.id.bt_trans) {
            animation = AnimationUtils.loadAnimation(this, R.anim.translate); // [cite: 1472]
        } else if (id == R.id.bt_random) {
            // GIẢI BÀI TẬP 1 [cite: 1849]
            int randomIndex = random.nextInt(anims.length);
            animation = AnimationUtils.loadAnimation(this, anims[randomIndex]);
        }

        if (animation != null) {
            ivAnimal.startAnimation(animation);
        }
    }
}