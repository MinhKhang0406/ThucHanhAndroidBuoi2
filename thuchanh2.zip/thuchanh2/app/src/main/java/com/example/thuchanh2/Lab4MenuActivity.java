package com.example.thuchanh2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class Lab4MenuActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab4_menu);

        findViewById(R.id.btn_lab4_login).setOnClickListener(this);
        findViewById(R.id.btn_lab4_menu).setOnClickListener(this);
        findViewById(R.id.btn_lab4_emoji).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_lab4_login) {
            startActivity(new Intent(this, Lab4LoginActivity.class));
        } else if (id == R.id.btn_lab4_menu) {
            startActivity(new Intent(this, Lab4TopicListActivity.class));
        } else if (id == R.id.btn_lab4_emoji) {
            startActivity(new Intent(this, Lab4EmojiActivity.class));
        }
    }
}