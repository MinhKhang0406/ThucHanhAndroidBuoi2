package com.example.thuchanh2;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast; // [cite: 715]
import androidx.appcompat.app.AppCompatActivity;

public class Lab4LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private TextView tvLoginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_login); // [cite: 135]

        // Yêu cầu của PDF là không có ActionBar [cite: 42]
        // Điều này đã được xử lý trong themes.xml (xem phần cuối)

        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        tvLoginButton = findViewById(R.id.tv_login_button);

        // GIẢI BÀI TẬP 1 [cite: 715]
        tvLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                String message = "Bạn đã đăng nhập thành công với email: " + email + " và mật khẩu: " + password;

                // Hiển thị Toast [cite: 715]
                Toast.makeText(Lab4LoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}