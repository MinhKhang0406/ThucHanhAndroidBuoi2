package com.example.thuchanh2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class Lab4EmojiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab4_emoji); // [cite: 708]
    }
}